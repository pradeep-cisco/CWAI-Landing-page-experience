import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { filterJobs, summarizeJobs } from './agent-scale-model.js';
import { getWorkGroups } from './agent-job-groups.js';
import { buildJobsPath } from './jobs-navigation.js';
import './agent-work-feed.css';

const STATES = [['running', 'Running'], ['waiting', 'Waiting'], ['review', 'Review'], ['completed', 'Completed']];
const format = value => Number(value || 0).toLocaleString('en-US');

function useReadingConditions(ref) {
  const [reduced, setReduced] = useState(() => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [visible, setVisible] = useState(() => typeof document === 'undefined' || !document.hidden);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const motionChanged = () => setReduced(preference.matches);
    const visibilityChanged = () => setVisible(!document.hidden);
    preference.addEventListener('change', motionChanged);
    document.addEventListener('visibilitychange', visibilityChanged);
    return () => { preference.removeEventListener('change', motionChanged); document.removeEventListener('visibilitychange', visibilityChanged); };
  }, []);
  useEffect(() => {
    if (!ref.current || typeof IntersectionObserver !== 'function') { setInView(true); return undefined; }
    const observer = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), { threshold: 0 });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, [ref]);
  return { reduced, visible, inView };
}

/** Every observation retains its own target. Rotation never advances a job. */
function supportedObservations(group, model, preferredIncidentId) {
  const jobs = group.jobs || [], ids = new Set(jobs.map(job => job.id));
  const records = (model.actions || []).filter(record => ids.has(record.job));
  const observation = (fact, job) => ({ ...fact, scope: job?.scope || job?.deviceId || group.scope, agentId: job?.agentId, incidentId: job?.incidentId, jobId: job?.id });
  const preferred = preferredIncidentId ? jobs.filter(job => job.incidentId === preferredIncidentId) : [];
  const candidates = [...new Map([...preferred, ...jobs.filter(item => summarizeJobs([item]).completed === 0)].map(job => [job.id, job])).values()];
  const sampledOwners = new Map();
  for (const job of candidates) {
    const previous = sampledOwners.get(job.agentId);
    if (!previous || !previous.finding && job.finding) sampledOwners.set(job.agentId, job);
  }
  const samples = preferred.length ? preferred : sampledOwners.size ? [...sampledOwners.values()] : jobs;
  const findings = samples.flatMap(job => {
    const text = job.landingFinding || (typeof job.finding === 'string' ? job.finding : job.finding?.text || job.finding?.detail);
    return text ? [observation({ id: `${job.id}-finding`, text, source: job.source }, job)] : [];
  });
  const supplied = samples.flatMap(job => (job.observations || []).filter(fact => fact.landingText).slice(0, 2).map(fact => observation({ ...fact, text: fact.landingText }, job)));
  const recorded = records.slice(-2).map(record => observation({ id: record.id, text: record.title, source: record.record, time: record.time }, jobs.find(job => job.id === record.job)));
  const validations = ids.size === 1 && ids.has('ROUTE-104') && model.proposal?.available && !records.length
    ? (model.proposal.validation || []).slice(0, 3).map((record, index) => observation({ id: `validation-${model.proposal.version}-${index}`, text: typeof record === 'string' ? record : record.detail || record.title, source: model.proposal.id }, jobs[0])) : [];
  const facts = ids.size === 1 && ids.has('ROUTE-104') ? [...recorded, ...validations, ...findings, ...supplied] : [...findings, ...supplied, ...recorded];
  const unique = facts.filter((fact, index) => fact.text && facts.findIndex(item => item.text === fact.text && item.scope === fact.scope) === index).slice(0, 3);
  return unique.length ? unique : [observation({ id: `${group.id}-checkpoint`, text: jobs[0]?.checkpoint || group.summary }, jobs[0])];
}

function StatusCounts({ counts, className = '', current = true, prioritize = false, id }) {
  const states = prioritize ? [STATES[2], STATES[1], STATES[0], STATES[3]] : STATES;
  const label = `${current ? '' : 'Last known: '}${counts.running} running, ${counts.waiting} waiting, ${counts.review} awaiting review, ${counts.completed} completed`;
  return <div id={id} className={className} role="group" aria-label={label}>
    {states.map(([state, title]) => counts[state] > 0 && <span key={state} data-state={state}><i aria-hidden="true"/><strong>{format(counts[state])}</strong>{' '}{state === 'review' ? 'Needs review' : title}</span>)}
  </div>;
}

function ManagerLink({ children, groupId, scope, onOpenManager, ...props }) {
  const query = { ...scope, ...(groupId ? { groupId } : {}) };
  return <Link to={buildJobsPath(query)} {...props} onClick={event => {
    if (!onOpenManager || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    onOpenManager(query, event);
  }}>{children}</Link>;
}

function JobGroup({ group, model, selected, selectedIncidentId, paused, index, scope, onOpenManager, onOpenIncident }) {
  const ref = useRef(null);
  const { reduced, visible, inView } = useReadingConditions(ref);
  const [reading, setReading] = useState(false), [factIndex, setFactIndex] = useState(0);
  const members = group.jobs || [], counts = group.counts || summarizeJobs(members);
  const preferredIncidentId = selectedIncidentId || (members.some(job => job.incidentId === 'INC-317') ? 'INC-317' : undefined);
  const signature = JSON.stringify(supportedObservations(group, model, preferredIncidentId));
  const facts = useMemo(() => JSON.parse(signature), [signature]);
  const current = model.sourceState === 'current';
  const stopped = paused || reduced || !visible || !inView || reading || !current;
  const fact = facts[Math.min(factIndex, facts.length - 1)];
  const statusId = `agent-work-${group.id}-status`;
  const findingId = `agent-work-${group.id}-finding`;
  const incidentId = selectedIncidentId || fact.incidentId;
  const incidentCount = incidentId ? members.filter(job => job.incidentId === incidentId).length : 0;
  const incidentRelated = Boolean(selectedIncidentId && incidentCount);
  const surface = group.id === 'risk-assessments' ? 'risk' : group.id === 'remediation' ? 'remediation' : 'network';

  useEffect(() => setFactIndex(0), [signature]);
  useEffect(() => {
    if (stopped || factIndex >= facts.length - 1) return undefined;
    const timer = setTimeout(() => setFactIndex(value => value + 1), 7200 + index * 600);
    return () => clearTimeout(timer);
  }, [stopped, factIndex, facts.length, index]);

  return <article className="agent-work-feed-item" onMouseEnter={() => setReading(true)} onMouseLeave={() => setReading(false)} onFocusCapture={() => setReading(true)} onBlurCapture={event => { if (!event.currentTarget.contains(event.relatedTarget)) setReading(false); }}>
    <hbr-card ref={ref} class="agent-work-feed-card" data-selected={selected} data-incident-related={String(incidentRelated)} data-tone={group.tone} data-group-id={group.id} data-surface={surface} data-running={String(current && counts.running > 0)} data-animated={String(!stopped && counts.running > 0)}>
      <div className="agent-work-card-content">
        {current && counts.running > 0 && <span className="agent-work-running-edge" aria-hidden="true"/>}
        <ManagerLink id={`agent-work-${group.id}`} className="agent-work-card-link" groupId={group.id} scope={scope} onOpenManager={onOpenManager} aria-label={`Open ${group.title} in Jobs manager`} aria-describedby={`${statusId} ${findingId}`}>
          <div className="agent-work-card-top"><h3>{group.title}</h3><span className="agent-work-card-total" data-job-count={members.length}>{format(members.length)} {members.length === 1 ? 'job' : 'jobs'}</span></div>
          <StatusCounts id={statusId} className="agent-work-status-counts" counts={counts} current={current} prioritize/>
          <div id={findingId} className="agent-work-card-observation" key={fact.id || fact.text}><p title={fact.text}>{fact.text}</p><span title={fact.source || ''}>{!current && <span className="agent-work-card-snapshot">Last known · </span>}{fact.scope}{fact.time && <time> · {fact.time}</time>}</span></div>
        </ManagerLink>
        {onOpenIncident && incidentCount > 0 && <div className="agent-work-incident-footer"><hbr-button class="agent-work-incident-action" variant="text" size="small" data-incident-id={incidentId} data-incident-count={incidentCount} arialabel={`Open incident ${incidentId}: ${incidentCount} linked ${incidentCount === 1 ? 'job' : 'jobs'} in ${group.title}`} onClick={event => onOpenIncident(incidentId, event)}><span className="agent-work-incident-copy"><hbr-icon name="nav-alerts" size="12px" aria-hidden="true"/>{incidentId} · {incidentCount} linked {incidentCount === 1 ? 'job' : 'jobs'}</span><hbr-icon name="arrow-right" size="13px" aria-hidden="true"/></hbr-button></div>}
      </div>
    </hbr-card>
  </article>;
}

function PauseIcon({ paused }) {
  return <svg width="15" height="15" viewBox="0 0 20 20" aria-hidden="true" fill="none">{paused ? <path d="M7 4.5 15 10l-8 5.5z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/> : <path d="M7 4.5v11M13 4.5v11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>}</svg>;
}

export default function AgentWorkFeed({ model, jobs = model?.jobs || [], selectedIssueId, selectedIncidentId, additionalJobs = [], domainFilter = 'all', agentFilter = 'all', onOpenManager, onOpenIncident }) {
  const sectionRef = useRef(null);
  const [manualPaused, setManualPaused] = useState(false);
  const { reduced } = useReadingConditions(sectionRef);
  const mergedJobs = [...new Map([...jobs, ...additionalJobs].map(job => [job.id, job])).values()];
  const scopedJobs = filterJobs(mergedJobs, { domainId: domainFilter, agentId: agentFilter });
  const counts = summarizeJobs(scopedJobs), scope = { domainId: domainFilter, agentId: agentFilter, experienceState: model?.experienceState };
  const { visibleGroups } = getWorkGroups(scopedJobs, model?.issues || [], selectedIssueId);
  const current = model?.sourceState === 'current';
  const pauseLabel = manualPaused ? 'Resume updates' : 'Pause updates';
  const hasTransitions = current && visibleGroups.some(group => group.counts.running > 0 || supportedObservations(group, model).length > 1);

  return <section ref={sectionRef} className="agent-work-feed" aria-labelledby="agent-work-feed-title" data-source={current ? 'current' : 'last-known'}>
    <div className="agent-work-feed-section-heading"><div className="agent-work-feed-heading-copy"><hbr-text variant="section-title"><h2 id="agent-work-feed-title">Jobs</h2></hbr-text><span className="agent-work-feed-grouping-label">By task</span></div><div className="agent-work-feed-tools"><span className="agent-work-feed-total" data-job-count={scopedJobs.length}>{format(scopedJobs.length)} {scopedJobs.length === 1 ? 'job' : 'jobs'}</span>{hasTransitions && <hbr-tooltip content="Pause visual updates. Jobs continue independently." hoist><hbr-button class="agent-work-pause" variant="text" size="small" arialabel={pauseLabel} aria={{ pressed: String(manualPaused) }} disabled={reduced} onClick={() => setManualPaused(value => !value)}><PauseIcon paused={manualPaused || reduced}/></hbr-button></hbr-tooltip>}<ManagerLink className="agent-work-manager-link" scope={scope} onOpenManager={onOpenManager}>Jobs manager<hbr-icon name="arrow-right" size="14px" aria-hidden="true"/></ManagerLink></div></div>
    <div className="agent-work-feed-status-line"><StatusCounts className="agent-work-feed-counts" counts={counts} current={current}/></div>
    {!current && <p className="agent-work-feed-source"><hbr-icon name="clock" size="15px"/>Updates interrupted. Showing last-confirmed jobs.</p>}
    <div className="agent-work-feed-list">{visibleGroups.map((group, index) => <JobGroup key={group.id} group={group} model={model} index={index} selected={Boolean(selectedIssueId && group.jobs.some(job => job.issueId === selectedIssueId))} selectedIncidentId={selectedIncidentId} paused={manualPaused} scope={scope} onOpenManager={onOpenManager} onOpenIncident={onOpenIncident}/>)}{!visibleGroups.length && <div className="agent-work-feed-empty"><hbr-icon name="clock" size="24px"/><div><strong>{current ? model.variant === 'quiet' ? 'No jobs in assessed scopes' : 'No jobs in this scope' : 'No retained jobs in this scope'}</strong><p>{current ? 'Choose another scope or start a job.' : 'Current conditions are unavailable.'}</p></div></div>}</div>
  </section>;
}
