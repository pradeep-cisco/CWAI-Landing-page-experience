import { filterJobs, jobCategory } from './agent-scale-model.js';
import { getIncidentThread } from './incident-thread-model.js';
import './incident-thread.css';

const shortLabels = { 'C-21': 'Affected link', 'C-22': 'Alternate path', 'C-23': 'Core ingress', 'R-41': 'Apply path adjustment', 'V-51': 'Affected link', 'V-52': 'Routing limits' };
const statusLabels = { running: 'Running', waiting: 'Waiting', review: 'Needs review', completed: 'Completed' };
const icons = { running: 'clock', waiting: 'clock', review: 'status-warning', completed: 'check-circle' };

function validFilters(model, domainFilter, agentFilter) {
  return (domainFilter === 'all' || model.network?.domains?.some(group => group.id === domainFilter)) &&
    (agentFilter === 'all' || Boolean(model.agents?.[agentFilter]));
}

/** Only explicit job dependencies produce connectors; category membership is not a dependency. */
function connectionBetween(previous, following) {
  if (!previous.length || !following.length) return null;
  if (previous.length > 1 && following.length === 1 && previous.every(job => following[0].inputJobIds?.includes(job.id))) return 'merge';
  if (previous.length === 1 && following.length > 1 && following.every(job => job.changeJobId === previous[0].id)) return 'branch';
  return null;
}

function Connector({ kind, count }) {
  return <div className={`agent-incident-connector agent-incident-${kind}`} data-connection={kind} style={{ '--incident-leg-count': count }} aria-hidden="true">
    {Array.from({ length: count }, (_, index) => <i key={index} style={{ '--incident-leg-index': index }}/>) }
    <b/>
  </div>;
}

function JobNode({ job, current, inScope, model, onInspect, onReview }) {
  const category = jobCategory(job);
  const canReview = current && inScope && category === 'review' && job.canReview && model.permissions?.reviewChange && job.proposal?.available && typeof onReview === 'function';
  const action = canReview ? onReview : onInspect;
  const status = current ? statusLabels[category] : `Last known · ${statusLabels[category].toLowerCase()}`;
  const accessible = `${canReview ? 'Review proposal' : 'Inspect job'}: ${job.id} · ${job.title} · ${status}${inScope ? '' : ' · Outside current filters'}`;
  return <button type="button" className="agent-incident-node" data-job-id={job.id} data-status={category} data-moving={String(current && inScope && category === 'running')} disabled={!inScope || typeof action !== 'function'} aria-label={accessible} aria-haspopup="dialog" onClick={event => { if (inScope && typeof action === 'function') action(job, event); }}>
    <hbr-icon name={icons[category]} size="16px" aria-hidden="true"/>
    <span className="agent-incident-node-title">{shortLabels[job.id] || job.threadLabel || job.shortTitle || job.title}</span>
    <span className="agent-incident-node-state">{status}</span>
    {!inScope && <span className="agent-incident-node-scope">Outside view</span>}
  </button>;
}

function verifiedMetric(jobs, scopedIds) {
  const job = jobs.find(item => item.id === 'V-51' && item.status === 'Verified' && scopedIds.has(item.id));
  const metric = job?.resultMetrics;
  if (!metric || !metric.source || !Number.isFinite(metric.before) || !Number.isFinite(metric.after)) return null;
  return { ...metric, jobId: job.id };
}

/** Incident-wide context stays distinct from category totals and never implies approval. */
export default function IncidentThread({ model, incidentId = 'INC-317', domainFilter = 'all', agentFilter = 'all', onClose, onInspect, onReview }) {
  if (!model || !validFilters(model, domainFilter, agentFilter)) return null;
  const thread = getIncidentThread(model, incidentId);
  if (!thread || !thread.jobs?.length) return null;
  const scopedJobs = filterJobs(thread.jobs, { domainId: domainFilter, agentId: agentFilter });
  if (!scopedJobs.length) return null;
  const current = model.sourceState === 'current';
  const scopedIds = new Set(scopedJobs.map(job => job.id));
  const byId = new Map(thread.jobs.map(job => [job.id, job]));
  const stages = (thread.stages || []).map(stage => ({ ...stage, jobs: (stage.jobIds || []).map(id => byId.get(id)).filter(Boolean) })).filter(stage => stage.jobs.length > 0);
  const metric = verifiedMetric(thread.jobs, scopedIds);
  const id = `agent-incident-${thread.id}`;
  const review = thread.jobs.some(job => jobCategory(job) === 'review');

  return <aside className="agent-incident-thread" aria-labelledby={`${id}-title`} data-incident-id={thread.id} data-source={current ? 'current' : 'last-known'}>
    <hbr-card class="agent-incident-surface">
      <header className="agent-incident-header">
        <div className="agent-incident-reference"><span>{thread.id}{thread.scope ? ` · ${thread.scope}` : ''}</span><hbr-button variant="text" size="small" class="agent-incident-close" arialabel="Close incident thread" onClick={onClose}><hbr-icon name="x" size="16px" aria-hidden="true"/></hbr-button></div>
        <h2 id={`${id}-title`} tabIndex={-1}>{thread.title}</h2>
        <div className="agent-incident-state" data-state={review ? 'review' : 'running'}><hbr-icon name={!current ? 'clock' : review ? 'status-warning' : 'nav-workflows'} size="15px" aria-hidden="true"/><span>{current ? thread.headline || thread.state : 'Last confirmed incident'}</span></div>
        <p className="agent-incident-summary">{current ? thread.summary : 'Updates interrupted. Showing last-confirmed work.'}</p>
        {metric && <div className="agent-incident-result" role="group" aria-label={`${current ? '' : 'Last-known '}${metric.label || 'Affected-link utilization'}: ${metric.before}${metric.unit || '%'} before, ${metric.after}${metric.unit || '%'} verified. Source: ${metric.source}`}><span>{current ? '' : 'Last known · '}{metric.label || 'Affected-link utilization'}</span><strong>{metric.before}{metric.unit || '%'} <span aria-hidden="true">→</span> <em>{metric.after}{metric.unit || '%'}</em></strong></div>}
      </header>
      <div className="agent-incident-work">
        <div className="agent-incident-work-heading"><h3>Related work</h3><span>{thread.jobs.length} linked {thread.jobs.length === 1 ? 'job' : 'jobs'}</span></div>
        {scopedJobs.length !== thread.jobs.length && <p className="agent-incident-filter-note">Incident-wide context · {scopedJobs.length} of {thread.jobs.length} jobs in this view</p>}
        {stages.map((stage, index) => {
          const previous = index > 0 ? stages[index - 1].jobs : [];
          const connection = connectionBetween(previous, stage.jobs);
          const count = connection === 'merge' ? previous.length : stage.jobs.length;
          const relationship = connection === 'merge' ? `Uses all ${previous.length} findings` : connection === 'branch' ? `Checks ${previous[0].id}` : `${stage.jobs.length} ${stage.jobs.length === 1 ? 'job' : 'jobs'}`;
          return <section className="agent-incident-stage" key={stage.id} data-stage={stage.id} aria-label={`${stage.title}, ${stage.jobs.length} ${stage.jobs.length === 1 ? 'job' : 'jobs'}`}>
            {connection && <Connector kind={connection} count={count}/>}
            <div className="agent-incident-stage-heading"><h4>{stage.title}</h4><span>{relationship}</span></div>
            <div className="agent-incident-nodes" data-count={stage.jobs.length} style={{ '--incident-node-count': Math.min(stage.jobs.length, 3) }}>{stage.jobs.map(job => <JobNode key={job.id} job={job} current={current} inScope={scopedIds.has(job.id)} model={model} onInspect={onInspect} onReview={onReview}/>)}</div>
          </section>;
        })}
        {thread.next && <p className="agent-incident-next">{typeof thread.next === 'string' ? thread.next : thread.next.text || thread.next.title}</p>}
      </div>
    </hbr-card>
  </aside>;
}
