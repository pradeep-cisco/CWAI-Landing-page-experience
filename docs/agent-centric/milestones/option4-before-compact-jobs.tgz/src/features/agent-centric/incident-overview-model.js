/** Incident presentation is independent of the Jobs overview; selection never changes job totals. */
import { filterJobs, jobCategory } from './agent-scale-model.js';
import { getTaskId } from './agent-job-tasks.js';
import { getIncidentThread } from './incident-thread-model.js';

const toneByState = { running: 'info', review: 'warning', waiting: 'warning', completed: 'positive', unknown: 'neutral', next: 'neutral' };
const stageIds = ['investigate', 'remediate', 'verify'];
const stageTitles = ['Investigate', 'Remediate', 'Verify'];
const stageFor = job => getTaskId(job) === 'verification' ? 'verify' : getTaskId(job) === 'remediation' ? 'remediate' : 'investigate';
const agentStep = (value, fallback) => {
  if (!value) return fallback;
  const step = String(value).replace(/^Next:\s*/i, '');
  return /^(the )?agent\b/i.test(step) ? step : `Agent’s next step: ${step}`;
};

function filtersAreValid(model, { domainId, agentId }) {
  return (domainId === 'all' || model.network?.domains?.some(group => group.id === domainId)) &&
    (agentId === 'all' || Boolean(model.agents?.[agentId]));
}

function hasOperationCompletion(job, model) {
  return (job.operation?.state === 'completed' && job.operation.id && job.operation.source && job.operation.current !== false) || (model.actions || []).some(record =>
    (record.jobId || record.job) === job.id && record.operationId && (record.source || record.record) && record.current !== false &&
    (record.id === 'operation-completed' || record.state === 'completed' || record.operationState === 'completed'));
}

function progressStage(id, jobs, model, current) {
  const title = stageTitles[stageIds.indexOf(id)];
  const base = { id, title, jobIds: jobs.map(job => job.id) };
  if (!jobs.length) return { ...base, state: 'next', label: 'Not started' };
  if (!current) return { ...base, state: 'unknown', label: 'Last known' };
  if (jobs.some(job => jobCategory(job) === 'review')) return { ...base, state: 'review', label: 'Review' };
  if (jobs.some(job => /decision submitted/i.test(job.status))) return { ...base, state: 'waiting', label: 'Confirming approval' };
  if (jobs.some(job => /held/i.test(job.status))) return { ...base, state: 'waiting', label: 'Held' };
  if (jobs.some(job => jobCategory(job) === 'waiting')) return { ...base, state: 'waiting', label: 'Waiting' };
  if (jobs.every(job => jobCategory(job) === 'completed')) {
    if (id === 'remediate' && !jobs.every(job => hasOperationCompletion(job, model))) return { ...base, state: 'waiting', label: 'Execution unconfirmed' };
    return { ...base, state: 'completed', label: 'Complete' };
  }
  return { ...base, state: 'running', label: id === 'remediate' && jobs.some(job => /checking/i.test(job.status)) ? 'Checking' : 'Running' };
}

function verifiedMetric(jobs, scopedIds, current) {
  const job = jobs.find(item => item.status === 'Verified' && scopedIds.has(item.id) &&
    item.resultMetrics?.source && Number.isFinite(item.resultMetrics.before) && Number.isFinite(item.resultMetrics.after));
  return job ? { ...job.resultMetrics, jobId: job.id, current: current && job.resultMetrics.current !== false } : null;
}

function criterionMet(metric) {
  if (!metric || metric.current === false || !Number.isFinite(metric.criterion)) return false;
  if (metric.comparison === 'at-or-below') return metric.after <= metric.criterion;
  if (metric.comparison === 'at-or-above') return metric.after >= metric.criterion;
  return false;
}

/** A declared incident and at least one explicit in-scope member are required. */
export function getIncidentDetail(model, incidentId, { domainId = 'all', agentId = 'all' } = {}) {
  if (!model || !filtersAreValid(model, { domainId, agentId })) return null;
  const incident = model.incidents?.find(item => item.id === incidentId);
  const thread = incident && getIncidentThread(model, incidentId);
  if (!thread?.jobs?.length) return null;
  const jobs = thread.jobs;
  const scopedJobs = filterJobs(jobs, { domainId, agentId });
  if (!scopedJobs.length) return null;
  const scopedIds = new Set(scopedJobs.map(job => job.id));
  const current = model.sourceState === 'current' && incident.current !== false && jobs.every(job => job.current !== false);
  const progress = stageIds.map(id => progressStage(id, jobs.filter(job => stageFor(job) === id), model, current));
  const [investigate, remediate, verify] = progress;
  const reviewJobs = jobs.filter(job => jobCategory(job) === 'review');
  const reviewJob = current && model.permissions?.reviewChange ? scopedJobs.find(job =>
    jobCategory(job) === 'review' && job.canReview && job.proposal?.available && job.proposal.reviewable !== false) || null : null;
  const metric = verifiedMetric(jobs, scopedIds, current);
  const change = jobs.find(job => stageFor(job) === 'remediate');
  const waiting = jobs.find(job => jobCategory(job) === 'waiting');
  const investigation = jobs.find(job => stageFor(job) === 'investigate' && jobCategory(job) !== 'completed');
  const checking = change && /checking/i.test(change.status);
  const submitted = change && /decision submitted/i.test(change.status);
  const held = change && /held/i.test(change.status);
  // Completed jobs alone do not resolve an incident. Resolution needs its own record.
  const resolved = Boolean(incident.resolution) && /resolved|closed/i.test(incident.state || '');
  let state = 'running', stateLabel = 'Investigating';
  let outcome = { title: 'Investigation is in progress', state: 'running', detail: '' };
  let now = agentStep(investigation?.nextStep || investigation?.checkpoint || thread.next, 'The agent is checking the incident evidence.');
  let actionNote = 'No action needed from you';

  if (!current) {
    state = 'unknown'; stateLabel = 'Updates interrupted';
    outcome = { title: 'Current incident state is unavailable', state: 'unknown', detail: 'Showing last-confirmed incident records.' };
    now = 'Current source visibility is required before new decisions or starts.';
    actionNote = 'Decisions are unavailable while updates are interrupted';
  } else if (resolved) {
    state = 'completed'; stateLabel = 'Resolved';
    outcome = { title: 'Incident resolution is recorded', state: 'completed', detail: typeof incident.resolution === 'string' ? incident.resolution : incident.resolution.summary || '' };
    now = 'The incident has a recorded resolution. Supporting jobs retain their own evidence.';
  } else if (reviewJobs.length) {
    state = 'review'; stateLabel = reviewJob ? 'Needs your review' : 'Awaiting review';
    outcome = { title: 'A proposed change is ready for review', state: 'review', detail: '' };
    now = reviewJob ? 'Review the proposed scope, impact checks and rollback before allowing a production change.'
      : 'The change is waiting for an eligible reviewer. Execution has not been confirmed.';
    actionNote = scopedJobs.some(job => reviewJobs.includes(job)) ? 'Delegated review authority is required' : 'The review job is outside the current filters';
  } else if (submitted) {
    state = 'waiting'; stateLabel = 'Confirming approval';
    outcome = { title: 'Your decision was submitted', state: 'waiting', detail: 'Approval confirmation is pending.' };
    now = 'Wait for authority confirmation before the agent checks execution prerequisites.';
  } else if (held) {
    state = 'waiting'; stateLabel = 'Change held';
    outcome = { title: 'The proposed change is held', state: 'waiting', detail: 'The change remains unissued.' };
    now = agentStep(change.nextStep, 'The agent retains the incident work while the change stays on hold.');
  } else if (checking) {
    stateLabel = 'Checking prerequisites';
    outcome = { title: 'Execution prerequisites are being checked', state: 'running', detail: 'Execution and verification remain unconfirmed.' };
    now = 'The agent is revalidating the approved scope and current prerequisites before execution.';
  } else if (waiting) {
    state = 'waiting'; stateLabel = /telemetry|source/i.test(`${waiting.status} ${waiting.checkpoint}`) ? 'Waiting for data' : 'Waiting';
    outcome = { title: stateLabel === 'Waiting for data' ? 'Fresh data is needed to continue' : 'A prerequisite is still pending', state: 'waiting', detail: '' };
    now = agentStep(waiting.nextStep || waiting.checkpoint, 'The agent is waiting for the recorded prerequisite.');
  } else if (verify.jobIds.length) {
    stateLabel = 'Verifying recovery';
    outcome = criterionMet(metric)
      ? { title: metric.label === 'Affected-link utilization' ? 'Link utilization is back within limits' : 'A recovery criterion has been met', state: 'completed', detail: 'Remaining checks must finish before the incident can close.' }
      : { title: 'Recovery checks are in progress', state: 'running', detail: '' };
    const unfinished = jobs.find(job => stageFor(job) === 'verify' && jobCategory(job) !== 'completed');
    now = unfinished ? incidentId === 'INC-317'
      ? 'The agent is checking routing stability and the approved change boundary before closing the incident.'
      : agentStep(unfinished.nextStep || unfinished.checkpoint, 'The agent is completing the remaining recovery checks.')
      : 'Verification jobs have finished; an incident resolution record is still required.';
    if (verify.state === 'completed') { state = 'waiting'; stateLabel = 'Awaiting closure'; }
  } else if (remediate.jobIds.length) {
    if (remediate.state === 'completed') {
      stateLabel = 'Awaiting verification';
      outcome = { title: 'The controller operation is complete', state: 'completed', detail: 'Recovery has not yet been verified.' };
      now = 'The agent needs post-change observations to verify the recorded operation.';
    } else if (remediate.label === 'Execution unconfirmed') {
      state = 'waiting'; stateLabel = 'Execution unconfirmed';
      outcome = { title: 'Controller completion is not established', state: 'waiting', detail: '' };
      now = 'A controller completion record is required before claiming the change finished.';
    } else {
      stateLabel = 'Remediating';
      outcome = { title: 'The agent is working on the response', state: 'running', detail: '' };
      now = agentStep(change?.nextStep || change?.checkpoint || thread.next, 'The agent is working on the recorded response.');
    }
  } else if (investigate.state === 'completed') {
    state = 'waiting'; stateLabel = 'Awaiting next step';
    outcome = { title: 'The assessment is complete', state: 'completed', detail: 'No incident resolution has been recorded.' };
    now = agentStep(thread.next, 'The agent is determining the next supported step.');
  } else if (jobs.every(job => getTaskId(job) === 'event-correlation')) {
    stateLabel = 'Monitoring incident';
    outcome = { title: 'Related events met incident criteria', state: 'running', detail: 'Event correlation does not establish the cause.' };
    now = agentStep(thread.next, 'The agent is continuing to correlate the recorded events.');
  }

  return {
    ...thread, current, state, stateLabel, tone: toneByState[state], outcome, progress, now,
    metric, reviewJob, jobs, scopedJobIds: [...scopedIds], jobCount: jobs.length,
    inScopeJobCount: scopedJobs.length, actionRequired: Boolean(reviewJob), actionNote,
    observedAt: model.observedAt || model.lastConfirmedAt || thread.observedAt || null,
  };
}

/** Stable relevance order supports pagination without changing jobs or creating associations. */
export function getIncidentOverview(model, filters = {}) {
  const seen = new Set();
  const priority = { review: 0, waiting: 1, running: 2, unknown: 3, completed: 4 };
  return (model?.incidents || []).flatMap((incident, index) => {
    if (seen.has(incident.id)) return [];
    seen.add(incident.id);
    const detail = getIncidentDetail(model, incident.id, filters);
    if (!detail) return [];
    return [{ id: detail.id, title: detail.title, scope: detail.scope, state: detail.state, stateLabel: detail.stateLabel,
      tone: detail.tone, jobCount: detail.jobCount, inScopeJobCount: detail.inScopeJobCount, current: detail.current,
      actionRequired: detail.actionRequired, index }];
  }).sort((a, b) => priority[a.state] - priority[b.state] || Number(b.id === model.featuredIncidentId) - Number(a.id === model.featuredIncidentId) || a.index - b.index)
    .map(({ index, ...incident }) => incident);
}
