const positive = value => Number.isFinite(value) && value > 0;

/** Keep inspection entirely inside Jobs so the incident queue stays available. */
export function getIncidentDrawerBounds(contentWidth, viewportWidth = contentWidth) {
  const content = positive(contentWidth) ? contentWidth : positive(viewportWidth) ? viewportWidth : 1280;
  const viewport = positive(viewportWidth) ? viewportWidth : content;
  const max = Math.max(1, Math.floor(Math.min(content, viewport)));
  const min = Math.min(480, max);
  const defaultWidth = min;
  return { min, max, defaultWidth };
}

export function clampIncidentDrawerWidth(width, bounds) {
  const value = positive(width) ? width : bounds.defaultWidth;
  return Math.min(bounds.max, Math.max(bounds.min, Math.round(value)));
}

/** A left-anchored drawer grows when its right edge moves right. */
export function incidentDrawerWidthForKey(key, width, bounds, step = 32) {
  const current = clampIncidentDrawerWidth(width, bounds);
  const increment = positive(step) ? step : 32;
  if (key === 'Home') return bounds.min;
  if (key === 'End') return bounds.max;
  if (key === 'ArrowLeft') return clampIncidentDrawerWidth(current - increment, bounds);
  if (key === 'ArrowRight') return clampIncidentDrawerWidth(current + increment, bounds);
  return null;
}

/** Partially visible Jobs controls remain usable beside the nonmodal drawer. */
export function isFullyCoveredByIncidentPanel(control, panel) {
  if (!control || !panel) return false;
  const values = [control.left, control.top, control.right, control.bottom, panel.left, panel.top, panel.right, panel.bottom];
  if (!values.every(Number.isFinite) || control.right <= control.left || control.bottom <= control.top) return false;
  return control.left >= panel.left && control.right <= panel.right && control.top >= panel.top && control.bottom <= panel.bottom;
}
