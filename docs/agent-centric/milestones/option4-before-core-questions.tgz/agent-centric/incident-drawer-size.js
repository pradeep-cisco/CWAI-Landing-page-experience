const positive = value => Number.isFinite(value) && value > 0;

/** Keep inspection entirely inside Jobs so the incident queue stays available. */
export function getIncidentDrawerBounds(contentWidth, viewportWidth = contentWidth) {
  const content = positive(contentWidth) ? contentWidth : positive(viewportWidth) ? viewportWidth : 1280;
  const viewport = positive(viewportWidth) ? viewportWidth : content;
  const max = Math.max(1, Math.floor(Math.min(content, viewport)));
  const min = Math.min(480, max);
  const defaultWidth = max;
  return { min, max, defaultWidth };
}

export function clampIncidentDrawerWidth(width, bounds) {
  const value = positive(width) ? width : bounds.defaultWidth;
  return Math.min(bounds.max, Math.max(bounds.min, Math.round(value)));
}

/** A right-anchored drawer grows when its left edge moves left. */
export function incidentDrawerWidthForKey(key, width, bounds, step = 32) {
  const current = clampIncidentDrawerWidth(width, bounds);
  const increment = positive(step) ? step : 32;
  if (key === 'Home') return bounds.min;
  if (key === 'End') return bounds.max;
  if (key === 'ArrowLeft') return clampIncidentDrawerWidth(current + increment, bounds);
  if (key === 'ArrowRight') return clampIncidentDrawerWidth(current - increment, bounds);
  return null;
}
